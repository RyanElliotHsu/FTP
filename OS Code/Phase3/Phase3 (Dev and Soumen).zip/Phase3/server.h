#ifndef SERVER_H
#define SERVER_H

int main();

#endif
