#ifndef SPLITTER_H
#define SPLITTER_H

char **lineSplitter(char *line);
char **pipeSplitter(char *line,  int pipeflag);

#endif
